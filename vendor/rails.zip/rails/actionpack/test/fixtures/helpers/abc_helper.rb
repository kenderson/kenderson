module AbcHelper
  def bare_a() end
  def bare_b() end
  def bare_c() end
end
